Biologically inspired vision models and derivated tools
=======================================================

1. A biological retina model for image spatio-temporal noise and luminance changes enhancement
2. A transient areas (spatio-temporal events) segmentation tool to use at the output of the Retina
3. High Dynamic Range (HDR >8bit images) tone mapping to (conversion to 8bit) use cas of the retina  
